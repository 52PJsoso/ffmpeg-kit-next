libswresample/swresample.o: libswresample/swresample.c libavutil/mem.h \
  libavutil/attributes.h libavutil/opt.h libavutil/rational.h \
  libavutil/channel_layout.h libavutil/version.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/dict.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/samplefmt.h \
  libswresample/swresample_internal.h libswresample/swresample.h \
  libavutil/frame.h libavutil/avutil.h libavutil/common.h \
  libavutil/error.h config.h libavutil/intmath.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/intfloat.h \
  libavutil/buffer.h libswresample/version_major.h \
  libswresample/audioconvert.h libavutil/avassert.h
