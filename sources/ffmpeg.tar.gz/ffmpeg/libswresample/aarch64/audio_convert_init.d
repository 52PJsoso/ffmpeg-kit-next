libswresample/aarch64/audio_convert_init.o: \
  libswresample/aarch64/audio_convert_init.c config.h \
  libavutil/attributes.h libavutil/cpu.h libavutil/version.h \
  libavutil/macros.h libavutil/avconfig.h libavutil/aarch64/cpu.h \
  libavutil/cpu_internal.h libavutil/samplefmt.h \
  libswresample/swresample_internal.h libswresample/swresample.h \
  libavutil/channel_layout.h libavutil/frame.h libavutil/avutil.h \
  libavutil/common.h libavutil/error.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/rational.h libavutil/intfloat.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/buffer.h libavutil/dict.h \
  libswresample/version_major.h libswresample/audioconvert.h
