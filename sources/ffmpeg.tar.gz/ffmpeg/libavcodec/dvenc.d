libavcodec/dvenc.o: libavcodec/dvenc.c config.h libavutil/attributes.h \
  libavutil/emms.h libavutil/log.h libavutil/version.h \
  libavutil/macros.h libavutil/avconfig.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/rational.h \
  libavutil/intfloat.h libavutil/mem_internal.h libavutil/opt.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/pixfmt.h \
  libavutil/samplefmt.h libavutil/pixdesc.h libavutil/thread.h \
  libavutil/error.h libavcodec/avcodec.h libavutil/avutil.h \
  libavutil/common.h libavutil/intmath.h libavutil/buffer.h \
  libavutil/frame.h libavcodec/codec.h libavutil/hwcontext.h \
  libavcodec/codec_id.h libavcodec/defs.h libavcodec/packet.h \
  libavcodec/version_major.h libavcodec/codec_internal.h libavcodec/dv.h \
  libavcodec/dv_internal.h libavcodec/dv_profile.h \
  libavcodec/dv_profile_internal.h libavcodec/dv_tablegen.h \
  libavcodec/dvdata.h libavcodec/encode.h libavcodec/fdctdsp.h \
  libavutil/attributes_internal.h libavcodec/mathops.h \
  libavcodec/me_cmp.h libavcodec/pixblockdsp.h libavcodec/put_bits.h \
  libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h
