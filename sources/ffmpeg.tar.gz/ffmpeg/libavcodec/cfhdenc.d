libavcodec/cfhdenc.o: libavcodec/cfhdenc.c libavutil/mem.h \
  libavutil/attributes.h libavutil/opt.h libavutil/rational.h \
  libavutil/channel_layout.h libavutil/version.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/dict.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/samplefmt.h libavutil/pixdesc.h \
  libavcodec/avcodec.h libavutil/avutil.h libavutil/common.h \
  libavutil/error.h config.h libavutil/intmath.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/intfloat.h \
  libavutil/buffer.h libavutil/frame.h libavcodec/codec.h \
  libavutil/hwcontext.h libavcodec/codec_id.h libavcodec/defs.h \
  libavcodec/packet.h libavcodec/version_major.h libavcodec/bytestream.h \
  libavutil/avassert.h libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavcodec/cfhd.h \
  libavcodec/cfhddsp.h libavcodec/cfhdencdsp.h \
  libavcodec/codec_internal.h libavcodec/encode.h libavcodec/put_bits.h
