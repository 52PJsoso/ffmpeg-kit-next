libavcodec/bgmc.o: libavcodec/bgmc.c libavutil/attributes.h \
  libavutil/mem.h libavcodec/bgmc.h libavcodec/get_bits.h \
  libavutil/common.h libavutil/error.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/version.h config.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/rational.h libavutil/intfloat.h libavutil/intreadwrite.h \
  libavutil/bswap.h libavutil/aarch64/intreadwrite.h \
  libavutil/avassert.h libavutil/log.h libavcodec/defs.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h
