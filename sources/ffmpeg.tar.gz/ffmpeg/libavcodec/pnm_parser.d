libavcodec/pnm_parser.o: libavcodec/pnm_parser.c libavutil/avassert.h \
  config.h libavutil/attributes.h libavutil/log.h libavutil/version.h \
  libavutil/macros.h libavutil/avconfig.h libavutil/imgutils.h \
  libavutil/pixdesc.h libavutil/pixfmt.h libavutil/rational.h \
  libavcodec/parser.h libavcodec/avcodec.h libavutil/samplefmt.h \
  libavutil/avutil.h libavutil/common.h libavutil/error.h \
  libavutil/intmath.h libavutil/internal.h libavutil/libm.h \
  libavutil/mathematics.h libavutil/intfloat.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/parser_internal.h libavcodec/pnm.h libavutil/half2float.h
