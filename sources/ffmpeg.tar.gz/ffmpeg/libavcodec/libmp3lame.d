libavcodec/libmp3lame.o: libavcodec/libmp3lame.c \
  /Users/mac/AndroidStudioProjects/ffmpeg-kit-next/prebuilt/android-arm64-24/lame/include/lame/lame.h \
  libavutil/channel_layout.h libavutil/version.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/attributes.h libavutil/common.h \
  libavutil/error.h config.h libavutil/intmath.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/rational.h \
  libavutil/intfloat.h libavutil/float_dsp.h libavutil/intreadwrite.h \
  libavutil/bswap.h libavutil/aarch64/intreadwrite.h libavutil/log.h \
  libavutil/mem.h libavutil/opt.h libavutil/dict.h libavutil/pixfmt.h \
  libavutil/samplefmt.h libavcodec/avcodec.h libavutil/avutil.h \
  libavutil/buffer.h libavutil/frame.h libavcodec/codec.h \
  libavutil/hwcontext.h libavcodec/codec_id.h libavcodec/defs.h \
  libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/audio_frame_queue.h libavcodec/codec_internal.h \
  libavcodec/encode.h libavcodec/mpegaudio.h \
  libavcodec/mpegaudiodecheader.h
