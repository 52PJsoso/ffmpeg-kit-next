libavcodec/h264_picture.o: libavcodec/h264_picture.c libavutil/avassert.h \
  config.h libavutil/attributes.h libavutil/log.h libavutil/version.h \
  libavutil/macros.h libavutil/avconfig.h libavutil/emms.h \
  libavcodec/error_resilience.h libavcodec/avcodec.h \
  libavutil/samplefmt.h libavutil/avutil.h libavutil/common.h \
  libavutil/error.h libavutil/intmath.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/rational.h \
  libavutil/intfloat.h libavutil/pixfmt.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/h264dec.h libavutil/mem_internal.h libavcodec/cabac.h \
  libavcodec/h264_parse.h libavcodec/get_bits.h libavutil/intreadwrite.h \
  libavutil/bswap.h libavutil/aarch64/intreadwrite.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h \
  libavcodec/h264_ps.h libavcodec/h264.h libavcodec/h2645_vui.h \
  libavcodec/h264_sei.h libavcodec/h2645_sei.h \
  libavutil/film_grain_params.h libavcodec/bytestream.h \
  libavcodec/itut35.h libavcodec/aom_film_grain.h libavcodec/dovi_rpu.h \
  libavutil/dovi_meta.h libavutil/csp.h libavcodec/codec_par.h \
  libavcodec/sei.h libavcodec/h2645_parse.h libavcodec/h264chroma.h \
  libavcodec/h264dsp.h libavcodec/h264pred.h libavcodec/h264qpel.h \
  libavcodec/qpeldsp.h libavcodec/mpegutils.h libavcodec/threadframe.h \
  libavcodec/videodsp.h libavcodec/h274.h libavcodec/hwaccel_internal.h \
  libavutil/refstruct.h
