libavcodec/g728dec.o: libavcodec/g728dec.c libavcodec/avcodec.h \
  libavutil/samplefmt.h libavutil/attributes.h libavutil/avutil.h \
  libavutil/common.h libavutil/error.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/version.h config.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/rational.h libavutil/intfloat.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/buffer.h libavutil/channel_layout.h \
  libavutil/dict.h libavutil/frame.h libavcodec/codec.h \
  libavutil/hwcontext.h libavcodec/codec_id.h libavcodec/defs.h \
  libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/celp_filters.h libavcodec/codec_internal.h \
  libavcodec/decode.h libavcodec/get_bits.h libavutil/intreadwrite.h \
  libavutil/bswap.h libavutil/aarch64/intreadwrite.h \
  libavutil/avassert.h libavcodec/mathops.h \
  libavutil/attributes_internal.h libavcodec/vlc.h libavcodec/g728data.h \
  libavcodec/lpc_functions.h libavcodec/ra288.h libavutil/mem_internal.h \
  libavutil/float_dsp.h libavutil/mem.h libavutil/opt.h \
  libavutil/thread.h libavcodec/g728_template.c
