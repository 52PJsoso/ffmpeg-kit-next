libavcodec/dss_sp.o: libavcodec/dss_sp.c libavutil/channel_layout.h \
  libavutil/version.h libavutil/macros.h libavutil/avconfig.h \
  libavutil/attributes.h libavutil/common.h libavutil/error.h config.h \
  libavutil/intmath.h libavutil/internal.h libavutil/libm.h \
  libavutil/mathematics.h libavutil/rational.h libavutil/intfloat.h \
  libavutil/mem_internal.h libavcodec/avcodec.h libavutil/samplefmt.h \
  libavutil/avutil.h libavutil/log.h libavutil/pixfmt.h \
  libavutil/buffer.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/codec_internal.h libavcodec/decode.h libavcodec/get_bits.h \
  libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h
