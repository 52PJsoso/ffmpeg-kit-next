libavcodec/msmpeg4dec.o: libavcodec/msmpeg4dec.c libavutil/thread.h \
  config.h libavutil/error.h libavutil/macros.h libavutil/avconfig.h \
  libavcodec/avcodec.h libavutil/samplefmt.h libavutil/attributes.h \
  libavutil/avutil.h libavutil/common.h libavutil/version.h \
  libavutil/intmath.h libavutil/internal.h libavutil/libm.h \
  libavutil/mathematics.h libavutil/rational.h libavutil/intfloat.h \
  libavutil/log.h libavutil/pixfmt.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/codec_internal.h libavcodec/mpegutils.h \
  libavcodec/mpegvideo.h libavcodec/blockdsp.h \
  libavcodec/error_resilience.h libavcodec/h264chroma.h \
  libavcodec/h263dsp.h libavcodec/hpeldsp.h libavcodec/idctdsp.h \
  libavcodec/mpegpicture.h libavcodec/threadprogress.h \
  libavcodec/qpeldsp.h libavcodec/videodsp.h libavutil/mem_internal.h \
  libavcodec/mpegvideodec.h libavcodec/get_bits.h \
  libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h \
  libavcodec/mpegvideodata.h libavcodec/msmpeg4.h \
  libavcodec/msmpeg4dec.h libavcodec/h263dec.h libavutil/imgutils.h \
  libavutil/pixdesc.h libavcodec/h263.h libavcodec/h263data.h \
  libavcodec/rl.h libavcodec/mpeg4videodec.h libavcodec/mpeg4videodsp.h \
  libavcodec/msmpeg4data.h libavcodec/msmpeg4_vc1_data.h
