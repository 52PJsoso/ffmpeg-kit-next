libavcodec/imm5.o: libavcodec/imm5.c libavutil/attributes.h \
  libavutil/attributes_internal.h libavutil/intreadwrite.h \
  libavutil/avconfig.h libavutil/bswap.h config.h \
  libavutil/aarch64/intreadwrite.h libavcodec/avcodec.h \
  libavutil/samplefmt.h libavutil/avutil.h libavutil/common.h \
  libavutil/error.h libavutil/macros.h libavutil/version.h \
  libavutil/intmath.h libavutil/internal.h libavutil/libm.h \
  libavutil/mathematics.h libavutil/rational.h libavutil/intfloat.h \
  libavutil/log.h libavutil/pixfmt.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/codec_internal.h
