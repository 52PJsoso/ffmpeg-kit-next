libavcodec/hq_hqa.o: libavcodec/hq_hqa.c libavutil/attributes.h \
  libavutil/mem_internal.h config.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/thread.h libavutil/error.h \
  libavcodec/avcodec.h libavutil/samplefmt.h libavutil/avutil.h \
  libavutil/common.h libavutil/version.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/rational.h libavutil/intfloat.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/buffer.h libavutil/channel_layout.h \
  libavutil/dict.h libavutil/frame.h libavcodec/codec.h \
  libavutil/hwcontext.h libavcodec/codec_id.h libavcodec/defs.h \
  libavcodec/packet.h libavcodec/version_major.h libavcodec/bytestream.h \
  libavutil/avassert.h libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavcodec/canopus.h \
  libavcodec/codec_internal.h libavcodec/decode.h libavcodec/get_bits.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h \
  libavcodec/hq_common.h libavcodec/hq_hqadata.h libavcodec/hq_hqadsp.h
