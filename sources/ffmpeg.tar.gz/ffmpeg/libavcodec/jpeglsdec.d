libavcodec/jpeglsdec.o: libavcodec/jpeglsdec.c libavutil/attributes.h \
  libavutil/mem.h libavcodec/avcodec.h libavutil/samplefmt.h \
  libavutil/avutil.h libavutil/common.h libavutil/error.h \
  libavutil/macros.h libavutil/avconfig.h libavutil/version.h config.h \
  libavutil/intmath.h libavutil/internal.h libavutil/libm.h \
  libavutil/mathematics.h libavutil/rational.h libavutil/intfloat.h \
  libavutil/log.h libavutil/pixfmt.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/codec_internal.h libavcodec/get_bits.h \
  libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h \
  libavcodec/golomb.h libavcodec/mjpegdec.h libavutil/mem_internal.h \
  libavutil/pixdesc.h libavutil/stereo3d.h libavcodec/blockdsp.h \
  libavcodec/bytestream.h libavcodec/exif.h libavcodec/hpeldsp.h \
  libavcodec/idctdsp.h libavcodec/jpegls.h libavcodec/jpeglsdec.h \
  libavcodec/mjpeg.h
