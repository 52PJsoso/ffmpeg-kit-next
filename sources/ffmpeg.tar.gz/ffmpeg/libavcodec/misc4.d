libavcodec/misc4.o: libavcodec/misc4.c libavutil/internal.h config.h \
  libavutil/attributes.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/rational.h libavutil/intfloat.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavcodec/avcodec.h \
  libavutil/samplefmt.h libavutil/avutil.h libavutil/common.h \
  libavutil/error.h libavutil/version.h libavutil/intmath.h \
  libavutil/log.h libavutil/pixfmt.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/codec_internal.h libavcodec/decode.h \
  libavcodec/bytestream.h libavutil/avassert.h libavcodec/mathops.h \
  libavutil/attributes_internal.h
