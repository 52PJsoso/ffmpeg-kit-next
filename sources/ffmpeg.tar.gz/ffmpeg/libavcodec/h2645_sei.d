libavcodec/h2645_sei.o: libavcodec/h2645_sei.c config_components.h \
  libavutil/ambient_viewing_environment.h libavutil/frame.h \
  libavutil/avutil.h libavutil/common.h libavutil/attributes.h \
  libavutil/error.h libavutil/macros.h libavutil/avconfig.h \
  libavutil/version.h config.h libavutil/intmath.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/rational.h \
  libavutil/intfloat.h libavutil/log.h libavutil/pixfmt.h \
  libavutil/buffer.h libavutil/channel_layout.h libavutil/dict.h \
  libavutil/samplefmt.h libavutil/display.h \
  libavutil/film_grain_params.h libavutil/mastering_display_metadata.h \
  libavutil/mem.h libavutil/refstruct.h libavutil/stereo3d.h \
  libavcodec/atsc_a53.h libavcodec/avcodec.h libavcodec/codec.h \
  libavutil/hwcontext.h libavcodec/codec_id.h libavcodec/defs.h \
  libavcodec/packet.h libavcodec/version_major.h libavcodec/decode.h \
  libavcodec/get_bits.h libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h \
  libavcodec/golomb.h libavcodec/h2645_sei.h libavcodec/bytestream.h \
  libavcodec/h2645_vui.h libavcodec/itut35.h libavcodec/aom_film_grain.h \
  libavcodec/dovi_rpu.h libavutil/dovi_meta.h libavutil/csp.h \
  libavcodec/codec_par.h libavcodec/sei.h
