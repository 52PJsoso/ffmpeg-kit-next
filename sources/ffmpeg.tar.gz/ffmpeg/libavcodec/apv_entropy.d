libavcodec/apv_entropy.o: libavcodec/apv_entropy.c libavcodec/apv.h \
  libavcodec/apv_decode.h libavcodec/apv_dsp.h libavcodec/cbs_apv.h \
  libavutil/buffer.h libavcodec/cbs.h libavcodec/codec_id.h \
  libavutil/avutil.h libavutil/common.h libavutil/attributes.h \
  libavutil/error.h libavutil/macros.h libavutil/avconfig.h \
  libavutil/version.h config.h libavutil/intmath.h libavutil/internal.h \
  libavutil/libm.h libavutil/mathematics.h libavutil/rational.h \
  libavutil/intfloat.h libavutil/log.h libavutil/pixfmt.h \
  libavutil/samplefmt.h libavcodec/codec_par.h \
  libavutil/channel_layout.h libavcodec/defs.h libavcodec/packet.h \
  libavutil/dict.h libavcodec/version_major.h libavcodec/get_bits.h \
  libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h \
  libavcodec/mathops.h libavutil/attributes_internal.h libavcodec/vlc.h \
  libavutil/frame.h libavcodec/put_bits.h
