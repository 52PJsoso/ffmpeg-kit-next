libavcodec/vc1_pred.o: libavcodec/vc1_pred.c libavcodec/mathops.h \
  libavutil/attributes_internal.h libavutil/attributes.h \
  libavutil/common.h libavutil/error.h libavutil/macros.h \
  libavutil/avconfig.h libavutil/version.h config.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/rational.h libavutil/intfloat.h libavcodec/mpegutils.h \
  libavutil/frame.h libavutil/avutil.h libavutil/log.h \
  libavutil/pixfmt.h libavutil/buffer.h libavutil/channel_layout.h \
  libavutil/dict.h libavutil/samplefmt.h libavcodec/avcodec.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/mpegvideo.h libavcodec/blockdsp.h \
  libavcodec/error_resilience.h libavcodec/h264chroma.h \
  libavcodec/h263dsp.h libavcodec/hpeldsp.h libavcodec/idctdsp.h \
  libavcodec/mpegpicture.h libavcodec/threadprogress.h \
  libavutil/thread.h libavcodec/qpeldsp.h libavcodec/videodsp.h \
  libavutil/mem_internal.h libavcodec/vc1.h libavcodec/get_bits.h \
  libavutil/intreadwrite.h libavutil/bswap.h \
  libavutil/aarch64/intreadwrite.h libavutil/avassert.h libavcodec/vlc.h \
  libavcodec/intrax8.h libavcodec/intrax8dsp.h libavcodec/wmv2dsp.h \
  libavcodec/vc1_common.h libavcodec/startcode.h libavcodec/vc1dsp.h \
  libavcodec/vc1_pred.h libavcodec/vc1data.h
