libavcodec/ivi.o: libavcodec/ivi.c libavutil/attributes.h \
  libavutil/imgutils.h libavutil/pixdesc.h libavutil/pixfmt.h \
  libavutil/avconfig.h libavutil/version.h libavutil/macros.h \
  libavutil/rational.h libavutil/mem.h libavutil/thread.h config.h \
  libavutil/error.h libavcodec/avcodec.h libavutil/samplefmt.h \
  libavutil/avutil.h libavutil/common.h libavutil/intmath.h \
  libavutil/internal.h libavutil/libm.h libavutil/mathematics.h \
  libavutil/intfloat.h libavutil/log.h libavutil/buffer.h \
  libavutil/channel_layout.h libavutil/dict.h libavutil/frame.h \
  libavcodec/codec.h libavutil/hwcontext.h libavcodec/codec_id.h \
  libavcodec/defs.h libavcodec/packet.h libavcodec/version_major.h \
  libavcodec/decode.h libavcodec/get_bits.h libavutil/intreadwrite.h \
  libavutil/bswap.h libavutil/aarch64/intreadwrite.h \
  libavutil/avassert.h libavcodec/mathops.h \
  libavutil/attributes_internal.h libavcodec/vlc.h libavcodec/ivi.h \
  libavcodec/ivi_dsp.h
